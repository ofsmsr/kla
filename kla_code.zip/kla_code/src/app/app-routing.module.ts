import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path: 'kla',
    loadChildren: () => import('./kla/kla.module').then(m => m.KlaModule)
  },
  {
    path: '',
    redirectTo: 'kla',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
