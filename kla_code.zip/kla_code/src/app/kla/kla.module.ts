import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { TodoComponent } from './todo/todo.component';

import { CreateRoutingModule } from './kla-routing.module';

@NgModule({
  declarations: [TodoComponent],
  imports: [
    CommonModule,
    FormsModule,
    CreateRoutingModule
  ]
})
export class KlaModule { }
