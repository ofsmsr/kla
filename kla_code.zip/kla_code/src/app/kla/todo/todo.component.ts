import { Component, OnInit } from '@angular/core';
import { cloneDeep } from 'lodash';

interface IDataSource {
  uid: string;
  task: string;
  status: string;
}

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent implements OnInit {
  task: string = null;
  status: string = null;
  currentEditData: IDataSource = null;
  allowedStatus: string[] = ['New', 'In-Progress', 'Completed'];
  allowedFilters: string[] = ['AllItems', ...this.allowedStatus];
  dataSource: IDataSource[] = [];
  backupDataSource: IDataSource[] = [];
  sortStatus: any = {
    'New': 1,
    'In-Progress': 2,
    'Completed': 3
  };

  trackByIndex = (index: number): number => index;

  constructor() { }

  ngOnInit() {
  }

  onAddOrEdit(uid?: string): void {

    const data = { uid: (crypto as any).randomUUID(), task: this.task, status: this.status};

    if (uid) {
      this.dataSource = this.dataSource.map(item => {
        return (item.uid === uid) ? {...item, task: this.task, status: this.status} : item;
      });
    } else {
      this.dataSource = [...this.dataSource, data];
    }
    this.updateBackup();
  }

  onEdit(item: IDataSource): void {
    this.currentEditData = item;
    this.task = this.currentEditData.task;
    this.status = this.currentEditData.status;
  }

  onDelete(uid: string): void {
    this.dataSource = this.dataSource.filter(item => item.uid !== uid);
    this.updateBackup();
  }

  onFilter(status: string): void {
    this.dataSource = status === 'AllItems' ? [...this.backupDataSource] : this.backupDataSource.filter(item => item.status === status);
  }

  onSort(): void {
    this.dataSource = this.backupDataSource.sort((a, b) => this.sortStatus[a.status] - this.sortStatus[b.status])
  }

  private updateBackup(): void {
    this.backupDataSource = cloneDeep(this.dataSource);
  }

}
